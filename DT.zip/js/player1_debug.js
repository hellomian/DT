/**
	author:Eric_wu wkf39988@gmail.com
**/
	var playbox = (function(){
		var _playbox = function(){
			var that = this;
			that.box = null;
			that.player = null;
			that.src = null;
			that.on = true;//Ĭ���Զ�����ʱΪtrue�������޸ĳ�false
			
			//
			that.autoPlayFix = {
				on: true,
				evtName: ("ontouchstart" in window)?"touchend":"click"
			}
		}
		_playbox.prototype = {
			init: function(box_ele){
				this.box = "string" === typeof(box_ele)?document.getElementById(box_ele):box_ele;
				this.player = this.box.nextSibling;
				this.player.isLoadedmetadata = false;
				this.player.autobuffer = true;
				var clickObj = {
					playbox:this,
					handleEvent: function(){
						this.playbox.play();
					}
				};
				this.box.addEventListener("click", clickObj);
				this.src = this.player.src;
				this.init = function(){return this;}
				this.autoPlayEvt(true);
				return this;
			},
			play: function(){
				if(this.autoPlayFix.on){
					this.autoPlayFix.on = true;
					this.autoPlayEvt(false);
				}
				this.on = !this.on;
				if(true == this.on){
					this.player.src = this.src;
					this.player.play();
				}else{
					this.player.pause();
					// this.player.src = null;
				}
				if("function" == typeof(this.play_fn)){
					this.play_fn.call(this);
				}
			},
			handleEvent: function(evt){
				if(evt.target == this.box){return;}
				this.play();
			},
			autoPlayEvt: function(important){
				if(important || this.autoPlayFix.on){
					document.body.addEventListener(this.autoPlayFix.evtName, this, false);
				}else{
					document.body.removeEventListener(this.autoPlayFix.evtName, this, false);
				}
			}
		}
		//
		return new _playbox();
	})();

	playbox.play_fn = function(){
		if(this.on){//����ʱ����ʽ��
			$("#audio_btn").removeClass("off").addClass("play_yinfu");
			$("#yinfu").removeClass("stop").addClass("rotate");
		}else{//��ͣʱ����ʽ
			$("#audio_btn").removeClass("play_yinfu").addClass("off");
			$("#yinfu").removeClass("rotate").addClass("stop");
		}
		//this.box.className = this.on?"play_yinfu on":"off";
	}