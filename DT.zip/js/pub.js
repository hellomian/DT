$(document).ready(function() {
	$("#index_logo").click(function() {
 		$("#mv01").toggleClass("mv01");
 		$("#mv02").toggleClass("mv02");
 		$("#mv03").toggleClass("mv03");
 		$("#mv04").toggleClass("mv04");
 		$("#mv05").toggleClass("mv05");
 		$("#mv06").toggleClass("mv06");
 		$(".index_menu .logo dt").toggleClass("mbg");

		
	});



});



